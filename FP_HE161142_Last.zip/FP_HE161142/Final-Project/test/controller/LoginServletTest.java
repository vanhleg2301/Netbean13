///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
// */
//package controller;
//
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import static org.junit.Assert.*;
//
///**
// *
// * @author Admin
// */
//public class LoginServletTest {
//    
//    public LoginServletTest() {
//    }
//    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }
//
//    /**
//     * Test of processRequest method, of class LoginServlet.
//     */
//    @Test
//    public void testProcessRequest() throws Exception {
//        System.out.println("processRequest");
//        HttpServletRequest request = null;
//        HttpServletResponse response = null;
//        LoginServlet instance = new LoginServlet();
//        instance.processRequest(request, response);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of doGet method, of class LoginServlet.
//     */
//    @Test
//    public void testDoGet() throws Exception {
//        System.out.println("doGet");
//        HttpServletRequest request = null;
//        HttpServletResponse response = null;
//        LoginServlet instance = new LoginServlet();
//        instance.doGet(request, response);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of doPost method, of class LoginServlet.
//     */
//    @Test
//    public void testDoPost() throws Exception {
//        System.out.println("doPost");
//        HttpServletRequest request = null;
//        HttpServletResponse response = null;
//        LoginServlet instance = new LoginServlet();
//        instance.doPost(request, response);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getServletInfo method, of class LoginServlet.
//     */
//    @Test
//    public void testGetServletInfo() {
//        System.out.println("getServletInfo");
//        LoginServlet instance = new LoginServlet();
//        String expResult = "";
//        String result = instance.getServletInfo();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//    
//}
